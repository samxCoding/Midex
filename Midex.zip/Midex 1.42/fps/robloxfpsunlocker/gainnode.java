public 302
 
Broxic0


LOxci(21393434234734922><INFO) {
protected switch (public static void main(String[] args) {
    
}private private
private static 

fsym
switch (switch (switch
private static protected 
 name() {
    
} name() {
    
}) {
    case value:
        
        break;

    default:
        break;
}) {
    case value:
        
        break;

    default:
        break;
}() {
    
} name;) {
    case value:
        
        break;

    default:
        break;
} name() {
    
}    
}